<?php
$con = mysqli_connect("localhost", "root", "", "live_search");

if(!$con){
    echo "Connection Failed" . mysqli_connect_error();
}
?>  